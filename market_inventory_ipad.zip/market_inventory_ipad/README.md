# Market Inventory — iPad Offline Version

This is a static Progressive Web App (PWA). There is no Python server and no database server.

## What it does
- Add inventory items
- Track quantity on hand
- +1 IN
- SOLD -1
- Custom quantity IN / OUT
- Search
- Movement history
- Backup inventory to JSON
- Restore inventory from JSON
- Works offline after installation
- Stores data locally on the iPad using IndexedDB

## Important iPad note
For iPadOS to install this as a true Home Screen app and allow offline caching, the files must be served from a normal HTTPS website at least once.

A very easy option is GitHub Pages:
1. Create a free GitHub repository.
2. Upload all files from this folder.
3. In Repository Settings -> Pages, publish from the main branch.
4. Open the generated HTTPS address in Safari on the iPad.
5. Tap Share -> Add to Home Screen.
6. Open the new Market Inventory icon once while online.
7. After that, the app works offline.

Other static hosting services such as Cloudflare Pages or Netlify also work.

## Backup recommendation
At the end of each fair, tap Backup and save the JSON file to iCloud Drive or Files.

Because this app is intentionally local-only, inventory on one iPad does not automatically sync to another device.
